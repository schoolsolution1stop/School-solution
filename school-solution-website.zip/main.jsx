
import React from 'react'
import ReactDOM from 'react-dom/client'
import SchoolSolutionWebsite from './SchoolSolutionWebsite.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SchoolSolutionWebsite />
  </React.StrictMode>,
)
